//import React, { useState } from 'react';
import { Box, AppBar, Toolbar, Typography } from '@mui/material';
import Sidebar from './components/Sidebar';
import MainContent from './components/MainContent';

const Dashboard = () => {
  return (
    <Box sx={{ display: 'flex' }}>
      {/* Left Sidebar - Adjust width here */}
      <Sidebar />

      {/* Main Content */}
      <Box component="main" sx={{ flexGrow: 1, bgcolor: 'background.default' }}>
        <AppBar position="sticky">
          <Toolbar>
            <Typography variant="h5">Teacher Feedback Dashboard</Typography>
          </Toolbar>
        </AppBar>

        <MainContent />
      </Box>
    </Box>
  );
};

export default Dashboard;
