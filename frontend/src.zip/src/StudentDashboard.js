//import React, { useState } from 'react';
import { Box, AppBar, Toolbar, Typography } from '@mui/material';
import Sidebar from './components/Sidebar';
import MainContent2 from './components/MainContent2';

const StudentDashboard = () => {
  return (
    <Box sx={{ display: 'flex' }}>
      {/* Left Sidebar - Adjust width here */}
      <Sidebar />

      {/* Main Content */}
      <Box component="main" sx={{ flexGrow: 1, bgcolor: 'background.default' }}>
        <AppBar position="sticky">
          <Toolbar>
            <Typography variant="h5">Student Feedback Dashboard</Typography>
          </Toolbar>
        </AppBar>

        <MainContent2 />
      </Box>
    </Box>
  );
};

export default StudentDashboard;
